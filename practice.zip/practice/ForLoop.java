/*class ForLoop{
    public static void main(String args[]){
        for(;true;){
            System.out.println("hello");
        }
    }
}*/
// Output :
    // hello
    // hello
    // hello
    // .
    // .
    // .

/*class ForLoop{
    public static void main(String args[]){
        for(;1 == 1;){
            System.out.println("hello");
        }
    }
}*/
// Output :
    // hello
    // hello
    // hello
    // .
    // .
    // .

/*class ForLoop{
    public static void main(String args[]){
        for(int i = 10;i > 0;){
            System.out.println("hello");
        }
    }
}*/
// Output :
    // hello
    // hello
    // hello
    // .
    // .
    // .

/*class ForLoop{
    public static void main(String args[]){
        int i=90;
        for(;i>100;i++){
            System.out.println(i);
        }
    }
}*/

// Program executed but nothing printed   
// because i = 90 which in for loop i > 100 is false

/*class ForLoop{
    public static void main(String args[]){
        int i=90;
        for(;i>100;i--){
            System.out.println(i);
        }
    }
}*/
// Program executed but nothing printed   
// because i = 90 which in for loop i > 100 is false


/*class ForLoop{
    public static void main(String args[]){
        int i=90;
        for(;;i++){
            System.out.println(i);
        }
    }
}*/
// Output : 
    // 90
    // 91
    // 92
    // .
    // .
    // .


/*class ForLoop{
    public static void main(String args[]){
        int i=90;
        for(;i<100;i++){
            System.out.println(i);
        }
    }
}*/
// Output :
    // 90
    // 91
    // 92
    // 93
    // 94
    // 95
    // 96
    // 97
    // 98
    // 99

class ForLoop{
    public static void main(String args[]){
        int i=90;
        for(;i<100;i+=2){
            System.out.println(i);
        }
    }
}
// Output :
    // 90
    // 92
    // 94
    // 96
    // 98