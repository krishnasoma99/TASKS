package in.java.practice;

public class TestNonParaConst {

	public static void main(String[] args) {
		
		NonParaConst obj = new NonParaConst();

	}

}
