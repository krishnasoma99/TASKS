class Increment{
    public static void main(String[] args){
        int i = 15 ,j = 20;

        System.out.println("i = " + i);
        System.out.println("i = " + i++); // post increment
        System.out.println("i = " + i);

        System.out.println("j = " + j);
        System.out.println("j = " + ++j); // pre increment
        System.out.println("j = " + j);
        
    }
}

// Output : 
    // i = 15
    // i = 15
    // i = 16
    // j = 20
    // j = 21
    // j = 21
