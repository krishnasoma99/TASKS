package in.java.practice;

public class Constructor {

	private String name = "asdfg";
	
	//if we not create constructor the java compiler create default constructor
	
	public String getName() {
		return name;
	}
}
