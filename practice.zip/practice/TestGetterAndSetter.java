package in.java.practice;

public class TestGetterAndSetter {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		
		p1.setAge(20);
		p1.setName("asdfg");
		
		System.out.println("person name is " + p1.getName());
		System.out.println("person Age is " + p1.getAge());
		

	}

}
