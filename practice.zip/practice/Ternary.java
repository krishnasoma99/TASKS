class Ternary{
    public static void main(String[] args){
        int num = 20;
        String result;
        result = (num > 0) ? "positive number" : "negative number";
        System.out.println(result);
        
    }
}
// Output : 
    // positive number