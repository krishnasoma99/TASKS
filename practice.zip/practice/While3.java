class While3{
    public static void main(String[] args){

        int i = 30;
        while(i > 20){
            System.out.println(i);
            // no increment or decrement
        }
    }
    
}
// Output :
    //30
    //30
    //30
    //30
    //.
    //.
    //.