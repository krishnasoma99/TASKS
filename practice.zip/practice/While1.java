class While1{
    public static void main(String[] args){

        int i = 30;
        while(i > 20){
            System.out.println(i);
            i--;
        }
    }
    
}
// Output :
    // 30
    // 29
    // 28
    // 27
    // 26
    // 25
    // 24
    // 23
    // 22
    // 21