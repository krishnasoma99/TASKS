class IfElse{
    public static void main(String[] args){
        int num = -40;
        if(num >0){
            System.out.println("Postive Number");
        }
        else{
            System.out.println("Negitive Number");
        }
        
    }
}
// Output :
    // Negitive Number