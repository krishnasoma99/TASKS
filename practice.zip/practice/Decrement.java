class Decrement{
    public static void main(String args[]){
        int i = 10 , j =20;
        System.out.println("i = " + i);
        System.out.println("i = " + i--); // post Decrement 
        System.out.println("i = " + i);

        System.out.println("j = " + j);
        System.out.println("j = " + --j); // pre Decrement 
        System.out.println("j = " + j);
    }
}
// OUtput :
    // i = 10
    // i = 10
    // i = 9
    // j = 20
    // j = 19
    // j = 19