package in.java.practice;

public class NonParaConst {
	
	//non-parametarized constructor
	NonParaConst(){
		System.out.println("i am constructor");
	}

}
