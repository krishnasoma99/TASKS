class ElseIf{
    public static void main(String[] args){
        int n = 0;
        if( n > 0 ){
            System.out.println("Positive Number");
        }
        else if( n < 0 ){
            System.out.println("Negitive Number");
        }
        else{
            System.out.println("The number is 0");
        }
        
    }
}

//Output :
    // The number is 0