import java.util.HashSet;
import java.util.Set;

class UniqueSubstringCounter {
    public static int countUniqueSubstrings(String s) {
        Set<String> result = new HashSet<>();
        int n = s.length();

        // Generate all substrings
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j <= n; j++){
                result.add(s.substring(i, j));
            }
        }
        return result.size();
    }
    public static void main(String args[]) {
        String input = "abcabc";
        int uniqueSubstringCount = countUniqueSubstrings(input);
        System.out.println("Total count of unique substrings: " + uniqueSubstringCount);
    }
}
// Output : 
    // Total count of unique substrings: 15