package in.java.practice;

public class TestParametarizedConst {

	public static void main(String[] args) {
		
		//call constructor by passing value
		ParametarizedConst obj = new ParametarizedConst("python");
		ParametarizedConst obj1 = new ParametarizedConst("c");
		ParametarizedConst obj2 = new ParametarizedConst("java");

	}

}
