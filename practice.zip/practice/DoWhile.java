class DoWhile{
    public static void main(String[] args){

        int i = 30;
        do{
            System.out.println("hi " + i);
            i--;
        }while(i > 20);
    }
    
}
// Output :
    // hi 30
    // hi 29
    // hi 28
    // hi 27
    // hi 26
    // hi 25
    // hi 24
    // hi 23
    // hi 22
    // hi 21